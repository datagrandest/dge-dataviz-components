import * as L from "leaflet";

export class GestureHandling extends L.Handler {}

export default GestureHandling;
